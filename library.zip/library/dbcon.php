<?php
$db = mysqli_connect("localhost", "root", "root", "library");
 
if($db){
    echo "connect : 성공<br>";
}
else{
    echo "disconnect : 실패<br>";
}
?>