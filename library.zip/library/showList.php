<?php


  //Initial page - Show all books
  
    for($no=1;$row=mysqli_fetch_row($result);$no++){
      echo "<tr>";     
      echo "<td>".$no."</td>";
        for($i=0;$i<(count($row));$i++){
          echo "<td>";
          echo $row[$i];
          echo "</td>";
        }
      echo "<td>
            <button type='submit'>Edit</button></td>";
      echo "<td>
            <button type='submit'>Delete</button></td>";
    echo "</tr>";
  }
?>