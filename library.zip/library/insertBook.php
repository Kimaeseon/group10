<?php
$con = mysqli_connect("localhost", "root", "root", "library");
 
if($con){
    //assigning posted value from newLibraryCustomerForm
    $ISBN = $_POST[ISBN];
    $title = $_POST[title];
    $author = $_POST[author];
    $genre = $_POST[genre];

    //insert information about new library customer
    $sql="INSERT INTO book(ISBN, title, author, genre) 
    VALUES('$ISBN', '$title', '$author', '$genre')";
    $result = mysqli_query($con, $sql);

    //check whether record is added and pop up notification 
    if($result){
        echo "<script> alert('1 record added')</script>";  
        header('location:layout/manage_book.php');      
    }
    echo mysqli_error($con);

        
    
}
else{
    echo "Could not connect";
}
?>
