<html>
	<body>
	<form action="insertLibrarian.php" method="post">

		New librarian<br>
			
			Librarian ID <input type = text name='librarianID'><br>
			Librarian PW <input type = text name='librarianPW'><br>
			First Name <input type = text name='firstName' autofocus/><br>
			Last Name<input type = text name='lastName' autofocus/><br>
			Telephone<input type = text name='telephone' autofocus/><br>
			Email<input type = email name='email'><br>	
			Address <input type = text name='address'><br>
			
					
		<input type = submit value="add">

</filedset>
</form>
</body>	
</html>