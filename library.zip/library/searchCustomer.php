<?php
	include('dbcon.php');

	if(isset($_POST['search_button'])){
       $search=$_POST['customerID'];
       $sql = "SELECT * FROM customer where customerId='$search'";
       $result = mysqli_query($db, $sql) or die(mysqli_error($con));

	    if($result){
	        $row=mysqli_fetch_array($result);
       		$firstname=$row['firstName'];
       		$lastname=$row['lastName'];
       		$state=$row['state'];
	    }
	}        
?>



