<?php
$con = mysqli_connect("localhost", "root", "root", "library");
 
if($con){
    echo "connect<br>";

    //assigning posted value from newLibraryCustomerForm
    $librarianID = $_POST[librarianID];
    $librarianPW = $_POST[librarianPW];
    $firstname = $_POST[firstName];
    $lastname = $_POST[lastName];
    $telephone = $_POST[telephone];
    $email = $_POST[email];
    $address = $_POST[address];

    //insert information about new library customer
    $sql="INSERT INTO librarian(librarianId, librarianPw, firstName, lastName, telephone, email, address) 
    VALUES('$librarianID', '$librarianPW', '$firstname', '$lastname', '$telephone', '$email', '$address')";
    $result = mysqli_query($con, $sql);

    //check whether record is added or not // SHOULD BE DELETEDED!!!!!!
    if($result){
        echo "<script> alert('1 record added')</script>";  
        echo("<script>location.replace('layout/new_book.php');</script>");      
    }

}
else{
    echo "Could not connect";
}
?>
