								<?php
								include('dbcon.php');
				
								session_start();
								$librarianID = $_POST['librarianID'];
								$librarianPW = $_POST['librarianPW'];
								echo "id:". $librarianID;
								echo "pw:". $librarianPW;
								//check if it is administrator or not
								$sql = "SELECT librarianId, librarianPw FROM librarian WHERE librarianID='admin123'";
								$result = mysqli_query($db, $sql) or die(mysqli_error($db));
								$row=mysqli_fetch_array($result);

								if($librarianID==$row['librarianId']&&$librarianPW==$row['librarianPw']){
									echo("<script>location.replace('layout/main_admin.php');</script>");
								}
								//If it is librarians
								else{
									$sql = "SELECT * FROM librarian WHERE librarianId='$librarianID'
									 AND librarianPw='$librarianPW'";
									$result = mysqli_query($db, $sql) or die(mysqli_error($db));
									$num_row = mysqli_num_rows($result);
										$row=mysqli_fetch_array($result);
										if( $num_row > 0 ) {
											header('location:layout/main.php');
											$_SESSION['id']=$row['librarianID'];
										}
										else{ 
										}
								}
								?>