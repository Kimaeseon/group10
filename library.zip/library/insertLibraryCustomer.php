<?php
$con = mysqli_connect("localhost", "root", "root", "library");
 
if($con){
    echo "connect<br>";


    //assigning posted value from newLibraryCustomerForm

    $firstname = $_POST[firstName];
    $lastname = $_POST[lastName];
    $telephone = $_POST[telephone];
    $email = $_POST[email];
    $address = $_POST[address];

    //insert information about new library customer
    $sql="INSERT INTO customer(firstName, lastName, telephone, email, address) 
    VALUES('$firstname', '$lastname', '$telephone', '$email', '$address')";
    $result = mysqli_query($con, $sql);

    //check whether record is added or not
    if($result){
        echo "<script> alert('1 record added')</script>";  
        echo("<script>location.replace('layout/new_customer.php');</script>");      
    }
    echo mysqli_error($con);

        
    
}
else{
    echo "Could not connect";
}
?>
