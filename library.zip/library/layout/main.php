<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>main</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/main-grid.css">
  <link rel="stylesheet" href="css/main.css">
</head>
<body class="body page-main clearfix">
  <header id="header" class="header js-header"></header>
  <p class="text text-1">Library Management System</p>
  <p class="text text-2"><span>FIK</span></p>
  <form>
  <button id="borrow/retrun" class="_button _button-1 js-logout" type="submit" formaction="borrow_return.php">Borrow / Return</button>
  <button id="managebook" class="_button _button-2 js-logout" formaction="manage_book.php">Manage Book</button>
  <button id="manageCustomer" class="_button _button-3 js-logout" formaction="manage_customer.php">Manage Customer</button>
  <button id="logout" class="_button _button-4 js-logout" type="submit" formaction="../logout.php">log out</button>
  <header id="header2" class="container"></header>
</form>
</body>
</html>
