<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>new_book</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/new_book-grid.css">
  <link rel="stylesheet" href="css/new_book.css">
</head>
<body class="body page-new_book clearfix">
  <div class="container"></div>
  <p class="text">Add a book information</p>

  <form action="../insertBook.php" method="post">
  <input class="_input _input-1" placeholder="ISBN" type="text" name="ISBN">
  <input class="_input _input-2" placeholder="Title" type="text" name="title">
  <input class="_input _input-3" placeholder="Author" type="text" name="author">
  <select class="_select" name="genre">
    <option value="History">History</option>
    <option value="Art">Art</option>
    <option value="Science">Science</option>
  </select>
  <button class="_button" type="submit">Make a new Book</button>
</form>
</body>
</html>