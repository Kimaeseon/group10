<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>edit_librarian</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/edit_librarian-grid.css">
  <link rel="stylesheet" href="css/edit_librarian.css">
</head>
<body class="body page-edit_librarian clearfix">
  <div class="container"></div>
  <p class="text">Edit a librarian information</p>
  <input class="_input _input-1" placeholder="ID" type="text">
  <input class="_input _input-2" placeholder="Password" type="text">
  <input class="_input _input-3" placeholder="First name" type="text">
  <input class="_input _input-4" placeholder="Last name" type="text">
  <input class="_input _input-5" placeholder="Telephone" type="text">
  <input class="_input _input-6" placeholder="Email" type="text">
  <input class="_input _input-7" placeholder="Address" type="text">
  <button class="_button">Edit a librarian</button>
</body>
</html>