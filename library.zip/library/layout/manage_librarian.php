<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>manage_librarian</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/manage_librarian-grid.css">
  <link rel="stylesheet" href="css/manage_librarian.css">

  <script language="javascript">
  function newlibrarian()
  {
    window.open("new_librarian.php","","width=400,height=600,location=no");
  }
  </script>

</head>
<body class="body page-manage_librarian clearfix">

  <button id="book_search_button" class="_button _button-1" onClick="javascript:newlibrarian">new librarian</button>

  <form action="" method="post">
  <select name="librarian_option" class="_select _select-1" >
    <option value="librarianID">Librarinan ID</option>
    <option value="firstname">First name</option>
    <option value="lastname">Last name</option>
  </select>
  <input name="search" class="_input" placeholder="librarian id" type="search">
  <button name="search_button" class="_button _button-2" type ="submit">search</button>
  </form>

  <select class="_select _select-2">
    <option value="Option">Option</option>
  </select>

  <div id="table" class="element">
  <table>
    <tr>
      <th>No</th>
      <th>Librarian ID</th>
      <th>Librarian PW</th>
      <th>First name</th>
      <th>Last name</th>
      <th>Telephone</th>
      <th>Email</th>
      <th>Address</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  <?php
  include ('../dbcon.php');

  if(isset($_POST['search_button'])){
      $search=$_POST['search'];
      $librarian_option=$_POST['librarian_option'];

      if($librarian_option=="librarianID"){
        $sql = "SELECT * FROM librarian where librarianId ='$search'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));

      }
      elseif($librarian_option=="firstname"){
        $sql = "SELECT * FROM librarian where firstName like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
      elseif($librarian_option=="lastname"){
        $sql = "SELECT * FROM librarian where lastName like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
    }
    else{
      $sql = "SELECT * FROM librarian";
      $result = mysqli_query($db, $sql) or die(mysqli_error($con));     
    }   
    
    if($result){
          include ('../showList.php');
    }
  ?>
  </table>
  </div>
</body>
</html>