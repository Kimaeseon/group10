<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>edit_book</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/edit_book-grid.css">
  <link rel="stylesheet" href="css/edit_book.css">
</head>
<body class="body page-edit_book clearfix">
  <div class="container"></div>
  <p class="text">Edit a book information</p>
  <input class="_input _input-1" placeholder="ISBN" type="text">
  <input class="_input _input-2" placeholder="Title" type="text">
  <input class="_input _input-3" placeholder="Author" type="text">
  <select class="_select">
    <option value="Option">Option</option>
  </select>
  <button class="_button">Edit a Book</button>
</body>
</html>