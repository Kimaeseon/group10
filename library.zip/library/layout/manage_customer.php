<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>manage_customer</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/manage_customer-grid.css">
  <link rel="stylesheet" href="css/manage_customer.css">

  <script language="javascript">
    function newCustomer()
    {
      window.open("new_customer.php","","width=400,height=600,location=no");
    }
    </script>

</head>

<body class="body page-manage_customer clearfix">

  <button id="search_button" class="_button _button-1" onClick="javascript:newCustomer();">new customer</button>
  
  <form action="" method="post">
  <select id="customer_option" name="customer_option" class="_select _select-1">
    <option value="customerID">Customer ID</option>
    <option value="firstname">First Name</option>
    <option value="lastname">Last Name</option>
  </select>
  <input id="book_search" class="_input" placeholder="customer id" type="search" name="search">
  <button id="book_search_button" class="_button _button-2" name="search_button" type ="submit">search</button>
  </form>

  <select class="_select _select-2">
    <option value="Option">Option</option>
  </select>

  <div id="table" class="element">
  <table>
    <tr>
      <th>No</th>
      <th>Customer ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Telephone</th>
      <th>Email</th>
      <th>Address</th>
      <th>State</th>
      <th>Borrow Count</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  <?php
  include ('../dbcon.php');

  if(isset($_POST['search_button'])){
      $search=$_POST['search'];
      $customer_option=$_POST['customer_option'];

      if($customer_option=="customerID"){
        $sql = "SELECT * FROM customer where customerId ='$search'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));

      }
      elseif($customer_option=="firstname"){
        $sql = "SELECT * FROM customer where firstName like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
      elseif($customer_option=="lastname"){
        $sql = "SELECT * FROM customer where lastName like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
    }
    else{
      $sql = "SELECT * FROM customer";
      $result = mysqli_query($db, $sql) or die(mysqli_error($con));     
    }   
    
    if($result){
          include ('../showList.php');
    }
  ?>
  </table>
  </div>
</body>
</html>