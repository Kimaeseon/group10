<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>borrow_return2</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/borrow_return2-grid.css">
  <link rel="stylesheet" href="css/borrow_return2.css">
</head>
<body class="body page-borrow_return2 clearfix">
  <div class="container container-1 clearfix">
    
    <form action="" method="post">
    <input class="_input _input-1" placeholder="customer id" type="search" name="customerID">
    <button class="_button _button-1" name="search_button">search</button>
  </form>
    <?php include('../searchCustomer.php');?>
    <p class="text text-1">First name : <?php echo $firstname;?></p>
    <p class="text text-2">Last name : <?php echo $lastname;?></p>
    <p class="text text-3">State : <?php echo $state;?></p>
    <p class="text text-4">Number of borrowable Book&nbsp;</p>
    <p id="return_date" class="text text-5">Return Date</p>
  </div>
  <div class="container container-2 clearfix">
    <input id="ISBN_search" class="_input _input-2" placeholder="ISBN" type="text">
    <button id="ISBN_search_btn" class="_button _button-2">search</button>
    <table>
            <tr>
                <th>No</th>
                <th>Title</th>
                <th>Author</th>
                <th>Borow Date</th>
                <th>Return Date</th>
                <th>State</th>
            </tr>

  </div>
</body>
</html>