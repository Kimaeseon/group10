<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>new_customer</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/new_customer-grid.css">
  <link rel="stylesheet" href="css/new_customer.css">
</head>
<body class="body page-new_customer clearfix">
  <div class="container"></div>
  <p class="text">Add a customer information</p>

  <form action="../insertLibraryCustomer.php" method="post">

  <input class="_input _input-1" placeholder="First name" type="text" name="firstName">
  <input class="_input _input-2" placeholder="Last name" type="text" name="lastName">
  <input class="_input _input-3" placeholder="Telephone" type="text" name="telephone">
  <input class="_input _input-4" placeholder="Email" type="text" name="email">
  <input class="_input _input-5" placeholder="Address" type="text" name="address">
  <button class="_button" type="submit">Make a new customer</button>

  </form>
</body>
</html>