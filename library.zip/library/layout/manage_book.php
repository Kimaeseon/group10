<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>manage_book</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/manage_book-grid.css">
  <link rel="stylesheet" href="css/manage_book.css">

  <script language="javascript">
  function newBook()
  {
    window.open("new_book.php","","width=400,height=560,location=no");
  }
  </script>

</head>
<body class="body page-manage_book clearfix">

  <form>
   <button id="new_book_btn" class="_button _button-1" onClick="javascript:newBook();">new book</button>
  </form>

  <form action="" method="post">
  <select class="_select _select-1" name="book_option">
    <option value="ISBN">ISBN</option>
    <option value="title">Title</option>
    <option value="author">Author</option>
  </select>
  <input class="_input" placeholder="ISBN" type="search" name="search">
  <button class="_button _button-2" name="search_button" type="submit">search</button>
  </form>

  <form action="" method="post">
  <select name="book_list_option" class="_select _select-2">
    <option value="all">All</option>
    <option value="on_loan">On loan</option>
    <option value="overdue">Overdue</option>
  </select>
  <form>
  <div id="table" class="element">
  <table>
    <tr>
      <th>No</th>
      <th>ISBN</th>
      <th>Title</th>
      <th>Author</th>
      <th>Genre</th>
      <th>State</th>
      <th>Borrow Count</th>
      <th>Borow Date</th>
      <th>Return Date</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  <?php
  include ('../dbcon.php');

  if(isset($_POST['search_button'])){
      $search=$_POST['search'];
      $book_option=$_POST['book_option'];

      if($book_option=="ISBN"){
        $sql = "SELECT * FROM book where ISBN='$search'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));

      }
      elseif($book_option=="title"){
        $sql = "SELECT * FROM book where title like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
      elseif($book_option=="author"){
        $sql = "SELECT * FROM book where author like '%{$search}%'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
    }
    /*
    elseif(isset($_POST['book_list_option'])){
    if($book_list_option=="all"){
        $sql = "SELECT * FROM book";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));
      }
    elseif($book_list_option=="on_loan"){
        $sql = "SELECT * FROM book where state like 'on loan'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
    elseif($book_list_option=="overdue"){
        $sql = "SELECT * FROM book where state like 'overdue'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($con));       
      } 
    }*/
    else{
      $sql = "SELECT * FROM book";
      $result = mysqli_query($db, $sql) or die(mysqli_error($con));     
    }   
    
    if($result){
          include ('../showList.php');
    }
  ?>
  </table>
  </div>   
</form>
</body>
</html>