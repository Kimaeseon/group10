<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>index</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/index-grid.css">
  <link rel="stylesheet" href="css/index.css">
</head>
<body class="body page-index clearfix">
  <div class="login"></div>
  <p class="text text-1">Library Management System</p>
  <p class="text text-2"><span>FIK</span></p>
  <form action="../login.php" method = "post">
  <input class="_input _input-1" placeholder="Id" type="text" name="librarianID">
  <input class="_input _input-2" placeholder="password" type="password" name="librarianPW">
  <button class="_button" type = "submit" >log in</button>
</body>
</html>